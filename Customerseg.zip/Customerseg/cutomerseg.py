# ==============================
# Customer Segmentation using KMeans
# ==============================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# ------------------------------
# 1. Create Sample Dataset
# ------------------------------

np.random.seed(42)

data = {
    "Annual Income": np.random.randint(15, 150, 200),
    "Spending Score": np.random.randint(1, 100, 200)
}

df = pd.DataFrame(data)

print("First 5 Rows:")
print(df.head())

# ------------------------------
# 2. Feature Selection
# ------------------------------

X = df[["Annual Income", "Spending Score"]]

# ------------------------------
# 3. Feature Scaling
# ------------------------------

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ------------------------------
# 4. Elbow Method
# ------------------------------

wcss = []

for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, random_state=42, n_init=10)
    kmeans.fit(X_scaled)
    wcss.append(kmeans.inertia_)

plt.figure()
plt.plot(range(1, 11), wcss)
plt.title("Elbow Method")
plt.xlabel("Number of Clusters")
plt.ylabel("WCSS")
plt.show()

# ------------------------------
# 5. Apply KMeans (5 clusters)
# ------------------------------

kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)

# ------------------------------
# 6. Visualize Clusters
# ------------------------------

plt.figure()

for i in range(5):
    plt.scatter(
        df[df["Cluster"] == i]["Annual Income"],
        df[df["Cluster"] == i]["Spending Score"],
        label=f"Cluster {i}"
    )

plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("Customer Segments")
plt.legend()
plt.show()

# ------------------------------
# 7. Cluster Analysis
# ------------------------------

print("\nCluster Summary:")
print(df.groupby("Cluster").mean())

# ------------------------------
# 8. Describe Each Cluster
# ------------------------------

print("\nCluster Descriptions:")

for i in range(5):
    cluster_data = df[df["Cluster"] == i]
    avg_income = cluster_data["Annual Income"].mean()
    avg_spending = cluster_data["Spending Score"].mean()

    income_level = "High" if avg_income > 80 else "Low"
    spending_level = "High" if avg_spending > 50 else "Low"

    print(f"Cluster {i}: {income_level} Income, {spending_level} Spending")