"""
Movie Rating Prediction using Collaborative Filtering (pandas + sklearn)
Modified to work without the 'surprise' library
"""

# ============================================================================ 
# STEP 1: Import Required Libraries
# ============================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import NearestNeighbors
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("MOVIE RATING PREDICTION USING COLLABORATIVE FILTERING (No Surprise)")
print("="*80)

# ============================================================================ 
# STEP 2: Load and Prepare the MovieLens Dataset
# ============================================================================
print("\n[1] LOADING MOVIELENS DATASET")
print("-"*50)

# For simplicity, create a sample dataset
np.random.seed(42)
n_users = 1000
n_movies = 500
n_ratings = 50000

ratings = pd.DataFrame({
    'user_id': np.random.randint(1, n_users+1, n_ratings),
    'movie_id': np.random.randint(1, n_movies+1, n_ratings),
    'rating': np.random.choice([1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5], n_ratings)
})

ratings = ratings.drop_duplicates(subset=['user_id', 'movie_id'])

movies = pd.DataFrame({
    'movie_id': range(1, n_movies+1),
    'title': [f'Movie {i}' for i in range(1, n_movies+1)]
})

users = pd.DataFrame({
    'user_id': range(1, n_users+1),
    'gender': np.random.choice(['M', 'F'], n_users),
    'age': np.random.randint(18, 70, n_users)
})

print(f"✓ Sample dataset created with {len(ratings)} ratings")
print(f"Dataset Statistics: Users: {ratings['user_id'].nunique()}, Movies: {ratings['movie_id'].nunique()}")

# ============================================================================ 
# STEP 3: Exploratory Data Analysis
# ============================================================================
print("\n[2] EXPLORATORY DATA ANALYSIS")
print("-"*50)

plt.figure(figsize=(12,5))
plt.hist(ratings['rating'], bins=9, edgecolor='black', alpha=0.7, color='skyblue')
plt.xlabel('Rating')
plt.ylabel('Frequency')
plt.title('Distribution of Ratings')
plt.show()

# ============================================================================ 
# STEP 4: Create User-Movie Matrix
# ============================================================================
print("\n[3] CREATING USER-MOVIE MATRIX")
print("-"*50)

user_movie_matrix = ratings.pivot(index='user_id', columns='movie_id', values='rating').fillna(0)

# ============================================================================ 
# STEP 5: Train/Test Split
# ============================================================================
print("\n[4] SPLITTING DATA INTO TRAIN/TEST")
print("-"*50)

train_data, test_data = train_test_split(ratings, test_size=0.2, random_state=42)

# ============================================================================ 
# STEP 6: User-Based Collaborative Filtering
# ============================================================================
print("\n[5] USER-BASED COLLABORATIVE FILTERING")
print("-"*50)

# Fit NearestNeighbors on users
user_matrix = user_movie_matrix.values
knn = NearestNeighbors(metric='cosine', algorithm='brute')
knn.fit(user_matrix)

def predict_rating(user_id, movie_id, k=5):
    """Predict rating for a given user-movie pair using k-nearest neighbors"""
    if user_id not in user_movie_matrix.index or movie_id not in user_movie_matrix.columns:
        return np.nan  # Unknown user or movie
    
    user_idx = user_id - 1
    movie_idx = movie_id - 1
    
    distances, indices = knn.kneighbors([user_matrix[user_idx]], n_neighbors=k+1)
    
    neighbor_ratings = []
    neighbor_distances = []
    
    for i, dist in zip(indices.flatten(), distances.flatten()):
        if i == user_idx:
            continue  # skip self
        rating = user_matrix[i, movie_idx]
        if rating > 0:
            neighbor_ratings.append(rating)
            neighbor_distances.append(1 - dist)
    
    if len(neighbor_ratings) == 0:
        return user_movie_matrix.loc[user_id].mean()  # fallback to user's average
    
    weighted_avg = np.dot(neighbor_ratings, neighbor_distances) / np.sum(neighbor_distances)
    return weighted_avg

# ============================================================================ 
# STEP 7: Evaluate Model
# ============================================================================
print("\n[6] EVALUATING MODEL")
print("-"*50)

test_ratings = test_data.copy()
preds = []

for idx, row in test_ratings.iterrows():
    pred = predict_rating(row['user_id'], row['movie_id'], k=5)
    preds.append(pred)

test_ratings['predicted'] = preds
rmse = np.sqrt(mean_squared_error(test_ratings['rating'], test_ratings['predicted']))
mae = mean_absolute_error(test_ratings['rating'], test_ratings['predicted'])
print(f"RMSE: {rmse:.3f}")
print(f"MAE: {mae:.3f}")

# ============================================================================ 
# STEP 8: Make Predictions for New Users/Movies
# ============================================================================
print("\n[7] MAKING EXAMPLE PREDICTIONS")
print("-"*50)

sample_user = 10
sample_movie = 5
predicted_rating = predict_rating(sample_user, sample_movie, k=5)
print(f"Predicted rating for User {sample_user} and Movie {sample_movie}: {predicted_rating:.2f}")

# ============================================================================ 
# STEP 9: Top-N Recommendations
# ============================================================================
print("\n[8] TOP-N RECOMMENDATIONS FOR USER")
print("-"*50)

def top_n_recommendations(user_id, n=10):
    unrated_movies = user_movie_matrix.columns[user_movie_matrix.loc[user_id]==0]
    predictions = [(movie, predict_rating(user_id, movie, k=5)) for movie in unrated_movies]
    predictions.sort(key=lambda x: x[1], reverse=True)
    top_movies = predictions[:n]
    
    print(f"Top {n} movies for User {user_id}:")
    for i, (movie_id, rating) in enumerate(top_movies, 1):
        movie_title = movies[movies['movie_id']==movie_id]['title'].values[0]
        print(f"{i:2d}. {movie_title} → Predicted Rating: {rating:.2f}")

top_n_recommendations(sample_user, n=10)